All Youtube video links for automated testing

Dương Trường Bình: https://youtu.be/O9YPeCXSWKc
Trần Đức Hoàng: https://youtu.be/3mqecoHsLhk
Nguyễn Tuấn Thanh: https://youtu.be/PKLjiMmmgGA
Nguyễn Thị Phương Trinh: https://youtu.be/Q5RA7pLuGx0
Phạm Văn Minh: https://youtu.be/3mqecoHsLhk